from django.contrib import admin
from Login_app.models import UserInfo


# Register your models here.

admin.site.register(UserInfo)
