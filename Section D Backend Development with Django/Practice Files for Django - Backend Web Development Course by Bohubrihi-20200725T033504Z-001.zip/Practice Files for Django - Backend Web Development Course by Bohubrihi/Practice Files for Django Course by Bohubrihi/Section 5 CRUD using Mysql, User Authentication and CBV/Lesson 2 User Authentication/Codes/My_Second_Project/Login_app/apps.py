from django.apps import AppConfig


class LoginAppConfig(AppConfig):
    name = 'Login_app'
