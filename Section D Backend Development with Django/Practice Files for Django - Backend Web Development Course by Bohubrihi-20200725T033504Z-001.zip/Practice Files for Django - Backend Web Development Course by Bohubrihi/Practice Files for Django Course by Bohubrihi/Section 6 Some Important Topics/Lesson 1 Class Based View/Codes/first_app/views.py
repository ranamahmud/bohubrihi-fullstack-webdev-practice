from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View, TemplateView, ListView, DetailView, CreateView, UpdateView, DeleteView, FormView
from first_app import models
from django.urls import reverse_lazy
import requests
from first_app import forms

# Create your views here.


class IndexView(ListView):
    context_object_name = 'musician_list'
    model = models.Musician
    template_name = 'first_app/index.html'

class MusicianDetail(DetailView):
    context_object_name = 'musician'
    model = models.Musician
    template_name = 'first_app/musician_details.html'

class AddMusician(CreateView):
    fields = ('first_name','last_name','instrument')
    model = models.Musician
    template_name = 'first_app/musician_form.html'

class UpdateMusician(UpdateView):
    fields = ('first_name','last_name', 'instrument')
    model = models.Musician
    template_name = 'first_app/musician_form.html'

class DeletMusician(DeleteView):
    context_object_name = 'musician'
    model = models.Musician
    success_url = reverse_lazy("first_app:index")
    template_name = 'first_app/delete_musician.html'

def github(request):
    user = {}
    if 'username' in request.GET:
        username = request.GET['username']
        url = 'https://api.github.com/users/%s' % username
        response = requests.get(url)
        user = response.json()
    return render(request, 'core/github.html', {'user': user})

class Git(FormView):
    template_name = 'git.html'
    form_class = forms.GitForm
    git_user = ''
    success_url = reverse_lazy("first_app:git")
    def form_valid(self, form):
        username = form.cleaned_data['username']
        print(username)
        url = 'https://api.github.com/users/%s' % username
        response = requests.get(url)
        Git.git_user = response.json()
        #print(self.user)
        #print(super().form_valid(form))
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context=super().get_context_data(**kwargs)
        context['git_user'] = Git.git_user
        return context
