from django.contrib import admin
from App_Login.models import UserProfile
# Register your models here.

admin.site.register(UserProfile)
