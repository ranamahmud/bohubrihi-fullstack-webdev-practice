from django.apps import AppConfig


class AppBlogConfig(AppConfig):
    name = 'App_Blog'
