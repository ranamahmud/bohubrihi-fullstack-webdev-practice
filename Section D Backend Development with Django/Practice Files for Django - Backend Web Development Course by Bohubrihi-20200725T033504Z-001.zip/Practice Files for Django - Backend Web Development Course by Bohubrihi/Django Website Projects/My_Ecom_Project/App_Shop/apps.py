from django.apps import AppConfig


class AppShopConfig(AppConfig):
    name = 'App_Shop'
