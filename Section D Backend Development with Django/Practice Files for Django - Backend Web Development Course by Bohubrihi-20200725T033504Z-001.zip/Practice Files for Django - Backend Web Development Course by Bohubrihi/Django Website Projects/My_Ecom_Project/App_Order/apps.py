from django.apps import AppConfig


class AppOrderConfig(AppConfig):
    name = 'App_Order'
